# DROPBOX

## Compilação
- Para compilar o cliente, utilize o comando "make dropboxclient"
- Para compilar o servidor, utilize o comando "make dropboxserver"
- Para executar o servidor, utilize o comando "./dropboxserver"
- Para executar o cliente, utilize o comando "./dropboxclient"

## Server e Client
- controle
- comunicação
- sincronização
- gerência de arquivo

## Server
- gerência de usuário

## Cliente
- interface com o usuário
